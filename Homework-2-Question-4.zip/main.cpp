#include <iostream>
#include <stack>

using namespace std; 


int main(){
  stack<char> stack; //delcare a stack with type char
  string s; 
  cout << "enter elements: ";
  getline( std::cin, s ); //store string input including spaces 


for (int i = 0; i < s.length(); i++){
  stack.push(s.at(i)); //store all elements to the stack
}


jump:
int a;
cout << "Enter position to be changed: ";
cin >> a; 
if (a > (s.length()-1)){
  cout << "invalid position try again \n";
goto jump; //if position is greater than the position of last degit, ask again
}

string c = ""; 
char n;
for (int i = 0; i <= (s.length() - a); i++){ //when the forloop reaches desired postion, change the element
  if(i == (s.length() - a)){ 
    cout << "enter new element: ";
    cin >> n;
    stack.push(n);
  }
c = c + stack.top(); //store the elements in string c temporarily to add it back to stack
stack.pop(); //remove the elements till you reach desired position
}

 for (int i = (c.length()-1); i > -1; i--){ //add the string with the changed element back into stack
  stack.push(c.at(i)); 
}

while (!stack.empty()){ //while stack isnt empty
      cout << stack.top(); //output top of stack
      stack.pop(); //delete element
    }



}