#include <iostream>
#include <stack>

using namespace std; 


int main(){
  stack<char> stack; //declare a stack with char
  string s; //delcare string s
  cout << "enter string to be reversed: ";
  getline( std::cin, s ); //store string input including spaces 
  s = s + ' '; //add a space at the end
  cout << "your string: " << s << endl;

  cout << "reversed string: ";
for (int i = 0; i < s.length(); i++){

  stack.push(s.at(i)); //

  if(s.at(i) == ' '){ //checks when a word has been detected

    while (!stack.empty()){ //while stack is not empty
      cout << stack.top(); //outputs the letters so the word comes out reversed
      stack.pop(); //deleted the letters so the stack can be reused
    }
  }


}
}